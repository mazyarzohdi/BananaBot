"""Sanaei VPN Telegram Bot."""
